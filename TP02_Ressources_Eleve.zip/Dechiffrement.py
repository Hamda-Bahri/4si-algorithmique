# TP N° 02 — Hamda ELBAHRI
# Chiffrement matriciel (3 colonnes)
# Ressource pédagogique pour le Bac Sciences de l’Informatique
from PyQt5.uic import loadUi
from PyQt5.QtWidgets import QApplication, QMessageBox
from numpy import array
from pickle import load


def RechercherEnregistrement(ident):
    # Module fourni : recherche d'un enregistrement dans Messages.dat.
    try:
        f = open("Messages.dat", "rb")
    except FileNotFoundError:
        return None
    resultat = None
    fin = False
    while not fin:
        try:
            e = load(f)
            if e["Id"] == ident:
                resultat = e
        except EOFError:
            fin = True
    f.close()
    return resultat


def Dechiffrer(ch):
    # A développer (question 4.b)
    pass


def Rechercher():
    # A développer (question 4.a)
    pass


def Afficher():
    # A développer (question 4.c)
    pass


app = QApplication([])
w = loadUi("........................")
w.show()
w.btnRechercher.clicked.connect(................)
w.btnDechiffrer.clicked.connect(................)
app.exec_()
