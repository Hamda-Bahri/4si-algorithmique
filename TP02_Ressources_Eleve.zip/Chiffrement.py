# TP N° 02 — Hamda ELBAHRI
# Chiffrement matriciel (3 colonnes)
# Ressource pédagogique pour le Bac Sciences de l’Informatique
from PyQt5.uic import loadUi
from PyQt5.QtWidgets import QApplication, QMessageBox
from numpy import array
from pickle import dump, load


def ValideId(ch):
    # Module fourni : ne pas modifier.
    return len(ch) == 4 and ch.isdecimal()


def Valider(ch):
    # A développer (question 2.a)
    pass


def NbMots(ch):
    # A développer (question 2.b)
    pass


def ChiffrerMessage(ch):
    # A développer : remplissage et parcours de la matrice (question 2.c)
    pass


def ExisteIdentifiant(ident):
    # Module fourni : ne pas modifier.
    try:
        f = open("Messages.dat", "rb")
    except FileNotFoundError:
        return False
    existe = False
    fin = False
    while not fin:
        try:
            e = load(f)
            if e["Id"] == ident:
                existe = True
        except EOFError:
            fin = True
    f.close()
    return existe


def Chiffrer():
    # A développer (question 2.c)
    pass


def Enregistrer():
    # A développer (question 2.d)
    pass


app = QApplication([])
w = loadUi("........................")
w.show()
w.btnChiffrer.clicked.connect(................)
w.btnEnregistrer.clicked.connect(................)
app.exec_()
